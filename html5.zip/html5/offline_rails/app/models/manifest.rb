class Manifest < ActiveRecord::Base
end
