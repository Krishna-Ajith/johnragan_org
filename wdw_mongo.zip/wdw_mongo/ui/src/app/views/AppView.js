define( function( require ) {
	
	var Backbone    = require('Backbone')
	  , Attractions = require('Attractions')
	  , Attraction = require('Attraction')
	  , AttractionsListView = require('AttractionsListView')
	  , AttractionView = require('AttractionView');
	
	var AppView = Backbone.View.extend({
		
		el: '#app-container',
		
		events: {
			'click #remove-attractions' : 'removeAttractions'
		},

        initialize: function() {
			this.attractions = new Attractions();
			this.attractionsListView = new AttractionsListView( { 
				'collection' : this.attractions,
				'el' : '#attractions_list_container'
			} );
			this.attractions.fetch();
			
			this.attraction = new Attraction({
			  list_item_photo_url: "data/images/mk/attractions/space-mountain-240.jpeg"
			  , name : "Space Mountain Old Title"
			  , summary: "Launch past the flashing lights of your space station into the soaring darkness of space! This classic Dark Ride dips and swerves as it rockets through the blackest reaches of the galaxy. Check the monitors as you exit for a glimpse of yourself in flight!"
			  , rating : 9
			  , wait : "Busy"
			  , intensity : 8
			  , height : "44"
			  , FP : "FP"
			  , pal_mickey : "Pal Mickey"
			  , rider_swap : "Rider Swap"
			  , wheelchair : "Wheelchair"
			})
			this.attractionView = new AttractionView({model: this.attraction, el: '#attraction_container'}).render();
			this.attraction.fetch();
        },

		removeAttractions: function() {
			console.log(this.attractions); // I see all the attractions in the javascript console, yet nothing shows up with _.each below...
        	_.each( this.attractions, function( attraction ) {
				console.log("inside removeAttractions - individual - why does it not arrive here when I have at least two models in the UI?");
        		attraction.destroy();
        	});
        	return false;
        }
	});
	return AppView;
});