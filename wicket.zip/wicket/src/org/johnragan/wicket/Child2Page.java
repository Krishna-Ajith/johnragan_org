/*
 * Child1.java
 *
 * Created on December 6, 2009, 06:30 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.johnragan.wicket;

/**
 *
 * @author John Ragan
 * 
 * See Child1Page for further details.
 */
public class Child2Page extends LayoutPage {

    public Child2Page() {
    }

}
