/*
 * Child1.java
 *
 * Created on December 6, 2009, 06:30 AM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.johnragan.wicket;

/**
 *
 * @author John Ragan
 * 
 * By extending the LayoutPage, we get something similar (somewhat) to what
 * Rails offers in layouts.
 */
public class Child1Page extends LayoutPage {

    public Child1Page() {
    }

}
