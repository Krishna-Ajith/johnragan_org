# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Depot::Application.config.secret_token = 'c01eb8684e6409d18ffc952682f45b52ecf5193d7a83d3d3eb2831dd2fe5dfe164e302a0ec9882a8ba78de36a52ed0c4f63be98b9fce53007d3c6dbca0cf3b92'
