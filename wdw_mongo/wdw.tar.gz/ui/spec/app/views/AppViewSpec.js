
define( ['AppView'], function( AppView ) 
{
	describe( 'AppView', function()
	{
		it( 'should exist', function(){
			expect( AppView ).toBeDefined();
		})
	})
});