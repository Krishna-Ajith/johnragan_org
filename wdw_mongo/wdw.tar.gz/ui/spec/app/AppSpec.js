define( ['app/App'], function( App ) 
{
	describe( 'App', function()
	{
		it( 'should exist', function(){
			expect( App ).toBeDefined();
		})
	})
});